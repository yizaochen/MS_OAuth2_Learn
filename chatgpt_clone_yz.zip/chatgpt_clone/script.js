const chatInput = document.querySelector("#chat-input");
const sendButton = document.querySelector("#send-btn");
const chatContainer = document.querySelector(".chat-container");
const newChatButton = document.querySelector("#new-chat-btn");
const histSessContainer = document.querySelector(".hist-sess-container");

let userText = null;

const createChatElement = (content, className) => {
  // Create new div and apply chat, specified class and set html content of div
  const chatDiv = document.createElement("div");
  chatDiv.classList.add("chat", className);
  chatDiv.innerHTML = content;
  return chatDiv; // Return the created chat div
};

const getChatResponse = async (incomingChatDiv) => {
  const pElement = document.createElement("p");

  // Send POST request to API, get response and set the reponse as paragraph element text
  // not implemented yet
  pElement.textContent = "This is a test response from the API";

  // Remove the typing animation, append the paragraph element and save the chats to local storage
  incomingChatDiv.querySelector(".typing-animation").remove();
  incomingChatDiv.querySelector(".chat-details").appendChild(pElement);
  localStorage.setItem("all-chats", chatContainer.innerHTML);
  chatContainer.scrollTo(0, chatContainer.scrollHeight);
};

const copyResponse = (copyBtn) => {
  // Copy the text content of the response to the clipboard
  const reponseTextElement = copyBtn.parentElement.querySelector("p");
  navigator.clipboard.writeText(reponseTextElement.textContent);
  copyBtn.textContent = "done";
  setTimeout(() => (copyBtn.textContent = "content_copy"), 1000);
};

const showTypingAnimation = () => {
  // Display the typing animation and call the getChatResponse function
  const html = `<div class="chat-content">
                    <div class="chat-details">
                        <img src="images/chatbot.jpg" alt="chatbot-img">
                        <div class="typing-animation">
                            <div class="typing-dot" style="--delay: 0.2s"></div>
                            <div class="typing-dot" style="--delay: 0.3s"></div>
                            <div class="typing-dot" style="--delay: 0.4s"></div>
                        </div>
                    </div>
                    <span onclick="copyResponse(this)" class="material-symbols-rounded">content_copy</span>
                </div>`;
  // Create an incoming chat div with typing animation and append it to chat container
  const incomingChatDiv = createChatElement(html, "incoming");
  chatContainer.appendChild(incomingChatDiv);
  chatContainer.scrollTo(0, chatContainer.scrollHeight);
  getChatResponse(incomingChatDiv);
};

const handleOutgoingChat = () => {
  userText = chatInput.value.trim(); // Get chatInput value and remove extra spaces
  if (!userText) return; // If chatInput is empty return from here

  // Clear the input field and reset its height
  chatInput.value = "";
  chatInput.style.height = `${initialInputHeight}px`;

  const html = `<div class="chat-content">
                    <div class="chat-details">
                        <img src="images/user.png" alt="user-img">
                        <p>${userText}</p>
                    </div>
                </div>`;

  // Create an outgoing chat div with user's message and append it to chat container
  const outgoingChatDiv = createChatElement(html, "outgoing");
  chatContainer.querySelector(".default-text")?.remove();
  chatContainer.appendChild(outgoingChatDiv);
  chatContainer.scrollTo(0, chatContainer.scrollHeight);
  setTimeout(showTypingAnimation, 500);
};

const changeActiveSession = (e) => {
    // Clear the chat container, in future this will implement to load history chat messages
    chatContainer.innerHTML = "";

    // find the active history session and remove the active class
    const activeHistSession = histSessContainer.querySelector(".active");
    activeHistSession.classList.remove("active");

    // add active class to the clicked history session
    const historySession = e.target.parentElement;
    historySession.classList.add("active");
    chatContainer.scrollTo(0, chatContainer.scrollHeight); // Scroll to bottom of the chat container
};

const addNewChat = () => {
    // Clear the chat container and remove the new chat button
    chatContainer.innerHTML = "";

    // find the active history session and remove the active class
    const activeHistSession = histSessContainer.querySelector(".active");
    activeHistSession.classList.remove("active");

    // add new chat session
    const historySession = document.createElement("div");
    historySession.classList.add("history-session", "active");

    // chat title
    const chatTitle = document.createElement("div");
    chatTitle.classList.add("chat-title");
    chatTitle.innerHTML = "ChatTitle-test";
    historySession.appendChild(chatTitle);
    chatTitle.addEventListener("click", changeActiveSession);

    // edit icon
    const editIcon = document.createElement("span");
    editIcon.classList.add("material-symbols-rounded", "edit");
    editIcon.innerHTML = "edit";
    historySession.appendChild(editIcon);

    // delete icon
    const deleteIcon = document.createElement("span");
    deleteIcon.classList.add("material-symbols-rounded", "delete");
    deleteIcon.innerHTML = "delete";
    historySession.appendChild(deleteIcon);

    // prepend the new chat session to the history session container
    histSessContainer.prepend(historySession);
    chatContainer.scrollTo(0, chatContainer.scrollHeight); // Scroll to bottom of the chat container
};

const initialInputHeight = chatInput.scrollHeight;

chatInput.addEventListener("input", () => {
  // Adjust the height of the input field dynamically based on its content
  chatInput.style.height = `${initialInputHeight}px`;
  chatInput.style.height = `${chatInput.scrollHeight}px`;
});

chatInput.addEventListener("keydown", (e) => {
  // If the Enter key is pressed without Shift and the window width is larger
  // than 800 pixels, handle the outgoing chat
  if (e.key === "Enter" && !e.shiftKey && window.innerWidth > 800) {
    e.preventDefault();
    handleOutgoingChat();
  }
});

sendButton.addEventListener("click", handleOutgoingChat);
newChatButton.addEventListener("click", addNewChat);

// for all chatTitle, add changeActiveSession event listener
const chatTitles = document.querySelectorAll(".chat-title");
chatTitles.forEach((chatTitle) => chatTitle.addEventListener("click", changeActiveSession));
